from random import randint
import os


def gen_data(data_path, hdfs_path):
    lineCnt = randint(5000000, 10000000)
    columnCnt = randint(5, 30)
    typeNum = randint(10, 200)
    # 1.1 gen local data
    os.system("rm -f {0}".format(data_path))
    print 'generating testData, path: ', data_path
    os.system("python For_2_classify.py {0} {1} {2} {3}"
              .format(data_path, lineCnt, columnCnt, typeNum))
    # 1.2 copy to hdfs
    os.system("hdfs dfs -rm {0}".format(hdfs_path))
    print 'copying to hdfs, path: ', hdfs_path
    os.system("hdfs dfs -copyFromLocal {0} {1}".format(data_path, hdfs_path))


def run_jar(hdfs_path, local_path):
    # 2. run jar
    driver_mem = randint(2, 4)
    exe_mem = randint(3, 6)
    exe_cores = randint(1, 5)
    cmd = '/home/spark-2.2.1-bin-hadoop2.6/bin/spark-submit --class RandomForestTestClassify ' \
          '--conf "spark.executor.extraJavaOptions=-XX:+UnlockCommercialFeatures -XX:+FlightRecorder -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.port=0 -Djava.util.logging.config.file=/home/spark-2.2.1-bin-hadoop2.6/conf/jmx.properties"  --conf "spark.driver.extraJavaOptions=-XX:+UnlockCommercialFeatures -XX:+FlightRecorder -Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -Dcom.sun.management.jmxremote.port=0 -Djava.util.logging.config.file=/home/spark-2.2.1-bin-hadoop2.6/conf/jmx.properties"  ' \
          '--master yarn --deploy-mode cluster --num-executors {0} --driver-memory {1}g  --executor-memory {2}g   ' \
          '--executor-cores {3} ~/wttttt/spark-examples/spark-examples-2.0-SNAPSHOT.jar {4} {5} {6}' \
        .format(randint(1, 6), driver_mem, exe_mem, exe_cores, hdfs_path, randint(3, 9), randint(3, 8))
    print 'running spark..., cmd: ', cmd
    print 'input file size: ', os.path.getsize(local_path)
    os.system(cmd)


if __name__ == "__main__":
    # 1. generate test data
    data_path = "/home/testData/random_forest_class1.txt"
    hdfs_path = "/home/testData/random_forest_class1.txt"
    gen_data(data_path, hdfs_path)
    run_jar(hdfs_path, data_path)


